package com.audioforge.app.ui.theme

import androidx.compose.ui.graphics.Color

// لوحة ألوان مبدئية بسيطة (يمكن تطويرها لاحقًا في مرحلة UI الاحترافي)
val ForgeBlue80 = Color(0xFF9FC9FF)
val ForgeGreen80 = Color(0xFFA8E6B0)
val ForgeGray80 = Color(0xFFD8DDE3)

val ForgeBlue40 = Color(0xFF1E5FA8)
val ForgeGreen40 = Color(0xFF2E8B4F)
val ForgeGray40 = Color(0xFF4B5560)

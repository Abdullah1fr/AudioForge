package com.audioforge.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.audioforge.app.ui.theme.AudioForgeTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            // نفرض RTL كاملاً بغض النظر عن لغة النظام (بند 23: RTL كامل).
            CompositionLocalProvider(androidx.compose.runtime.staticCompositionLocalOf { LayoutDirection.Rtl }) {
                AudioForgeTheme {
                    Surface(modifier = Modifier.fillMaxSize()) {
                        HomeScreen()
                    }
                }
            }
        }
    }
}

/**
 * الشاشة الرئيسية المبدئية (Skeleton) — المرحلة 1 من ترتيب التطوير.
 * لا يوجد بعد Audio Engine حقيقي، ولا اتصال بالخدمة أو DataStore.
 * الهدف الوحيد هنا: التأكد أن المشروع يبني، والعربية وRTL يعملان.
 */
@Composable
fun HomeScreen() {
    var engineOn by remember { mutableStateOf(false) }

    Scaffold { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(20.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = stringRes(R.string.app_name),
                style = MaterialTheme.typography.titleLarge
            )
            Text(
                text = stringRes(R.string.app_tagline),
                style = MaterialTheme.typography.bodyLarge
            )

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = if (engineOn) stringRes(R.string.home_engine_status_on)
                               else stringRes(R.string.home_engine_status_off),
                        style = MaterialTheme.typography.titleLarge
                    )
                    Text(text = stringRes(R.string.home_current_preset))
                    Text(text = stringRes(R.string.home_master_gain) + ": 0 dB")
                    Text(text = stringRes(R.string.home_level_meter_unavailable))

                    Button(
                        onClick = { engineOn = !engineOn },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = if (engineOn) stringRes(R.string.home_toggle_engine_off)
                                   else stringRes(R.string.home_toggle_engine_on)
                        )
                    }
                }
            }

            OutlinedButton(onClick = { /* سيُفعّل في مرحلة AI Layer */ }, modifier = Modifier.fillMaxWidth()) {
                Text(text = stringRes(R.string.home_smart_mode))
            }
            OutlinedButton(onClick = { /* سيُفعّل في مرحلة UI الاحترافي */ }, modifier = Modifier.fillMaxWidth()) {
                Text(text = stringRes(R.string.home_pro_mode))
            }
            OutlinedButton(onClick = { /* سيُفعّل في مرحلة Settings */ }, modifier = Modifier.fillMaxWidth()) {
                Text(text = stringRes(R.string.home_settings))
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = stringRes(R.string.mvp_placeholder_note),
                style = MaterialTheme.typography.labelLarge
            )
        }
    }
}

@Composable
private fun stringRes(id: Int): String =
    androidx.compose.ui.res.stringResource(id = id)

@Preview(showBackground = true)
@Composable
fun HomeScreenPreview() {
    AudioForgeTheme {
        HomeScreen()
    }
}

// المستوى الأعلى لملف بناء Gradle. لا تضع هنا اعتماديات التطبيق مباشرة.
plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}
